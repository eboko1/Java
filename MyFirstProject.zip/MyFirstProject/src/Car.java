
public class Car {
int numberOfDoors;
String color;

//Starts machine
 boolean startEngine(){
	return true;
}
//Stop machine
 boolean stopEngine(){
	
	return false;
}
}
