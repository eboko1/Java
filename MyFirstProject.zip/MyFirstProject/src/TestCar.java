
public class TestCar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Car car1=new Car(); //created instanced car1
	Car car2=new Car(); // created instanced car2
	
	car1.color="Blue";
	car2.color="Red";
	
System.out.println("I've pointed the cars!!");
System.out.println("The color of car1 is "+car1.color);
System.out.println("The color of car1 is "+car2.color);

	}

}
